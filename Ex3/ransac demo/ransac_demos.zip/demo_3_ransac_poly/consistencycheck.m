function ok=consistencycheck(parm,x,N)

ok = size(x,2)>0.65*N;
